#ifndef HEADER_H
#define HEADER_H

#include <vector>
#include <string>
using namespace std;

// Struktur untuk merepresentasikan graf jarak antar kota
struct TSP {
    int numCities;              // Jumlah kota
    vector<string> cityNames;   // Nama-nama kota
    vector<vector<int>> distanceMatrix; // Matriks jarak antar kota
};

// Fungsi untuk menyelesaikan TSP dengan brute force
void solveTSPBruteForce(TSP& tsp);

#endif // HEADER_H
