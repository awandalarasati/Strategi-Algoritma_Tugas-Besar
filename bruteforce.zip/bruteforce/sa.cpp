#include "header.h"
#include <iostream>
#include <vector>
#include <algorithm>

// Fungsi untuk menghitung biaya tur
int calculateTourCost(const vector<int>& tour, const TSP& tsp) {
    int cost = 0;
    for (int i = 0; i < tsp.numCities; ++i) {
        int from = tour[i];
        int to = tour[(i + 1) % tsp.numCities];
        cost += tsp.distanceMatrix[from][to];
    }
    return cost;
}

// Fungsi untuk mencetak jalur terbaik
void printBestTour(const vector<int>& bestTour, const TSP& tsp) {
    cout << "Jalur terbaik: ";
    for (int i = 0; i < tsp.numCities; ++i) {
        cout << tsp.cityNames[bestTour[i]];
        if (i < tsp.numCities-1 )
            cout << " ";
    }
    cout << " " << tsp.cityNames[bestTour[0]];
    cout << endl;
}

// Fungsi untuk menyelesaikan TSP dengan brute force
void solveTSPBruteForce(TSP& tsp) {
    vector<int> tour(tsp.numCities);
    vector<int> bestTour(tsp.numCities);
    int minCost = INT_MAX;

    // Inisialisasi tur awal
    for (int i = 0; i < tsp.numCities; ++i)
        tour[i] = i;

    // Permutasi semua kemungkinan tur
    do {
        int currentCost = calculateTourCost(tour, tsp);
        if (currentCost < minCost) {
            minCost = currentCost;
            bestTour = tour;
        }
    } while (next_permutation(tour.begin() + 1, tour.end()));

    // Output hasil
    printBestTour(bestTour, tsp);
    cout << "Biaya yang dibutuhkan: " << minCost << endl;
}
