#include <iostream>
#include "header.h"

int main() {
    TSP tsp;

    cout << "-----IMPLEMENTASI METODE BRUTE FORCE-----" << endl;
    // Input jumlah kota
    cout << "Masukkan jumlah kecamatan: ";
    cin >> tsp.numCities;

    // Input nama-nama kota
    tsp.cityNames.resize(tsp.numCities);
    cout << "Masukkan nama-nama kecamatan:\n";
    for (int i = 0; i < tsp.numCities; ++i)
        cin >> tsp.cityNames[i];

    // Input matriks jarak antar kota
    tsp.distanceMatrix.resize(tsp.numCities, vector<int>(tsp.numCities));
    cout << "Masukkan matriks jarak antar kecamatan:\n";
    for (int i = 0; i < tsp.numCities; ++i) {
        for (int j = 0; j < tsp.numCities; ++j)
            cin >> tsp.distanceMatrix[i][j];
    }

    // Solusi dengan metode brute force
    solveTSPBruteForce(tsp);

    // Output kelas kompleksitas waktu
    cout << "Kompleksitas waktu: O(n!)" << endl;

    return 0;
}
