#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include <vector>
#include <string>
using namespace std;

int findNearestCity(int currentCity, const std::vector<std::vector<int>>& distanceMatrix, const std::vector<bool>& visited);

#endif // HEADER_H_INCLUDED
