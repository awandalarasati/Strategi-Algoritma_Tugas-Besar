#include "header.h"
#include <limits>

// Fungsi untuk mencari kota terdekat yang belum dikunjungi
int findNearestCity(int currentCity, const vector<vector<int>>& distanceMatrix, const vector<bool>& visited) {
    int n = distanceMatrix.size();
    int nearestCity = -1;
    int minDistance = numeric_limits<int>::max();

    for (int i = 0; i < n; ++i) {
        if (!visited[i] && distanceMatrix[currentCity][i] < minDistance) {
            minDistance = distanceMatrix[currentCity][i];
            nearestCity = i;
        }
    }

    return nearestCity;
}
