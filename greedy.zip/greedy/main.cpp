#include <iostream>
#include <vector>
#include <string>
#include "header.h"

using namespace std;

int main() {
    cout << "-----IMPLEMENTASI METODE GREEDY-----" << endl;

    int numCities;
    cout << "Masukkan jumlah kecamatan: ";
    cin >> numCities;

    vector<string> cityNames(numCities);
    cout << "Masukkan nama-nama kecamatan:\n";
    for (int i = 0; i < numCities; ++i) {
        cin >> cityNames[i];
    }

    vector<vector<int>> distanceMatrix(numCities, vector<int>(numCities));
    cout << "Masukkan matriks jarak antar kecamatan:\n";
    for (int i = 0; i < numCities; ++i) {
        for (int j = 0; j < numCities; ++j) {
            cin >> distanceMatrix[i][j];
        }
    }

    vector<int> bestPath;
    vector<bool> visited(numCities, false);
    int currentCity = 0;
    visited[currentCity] = true;
    bestPath.push_back(currentCity);
    int totalCost = 0;

    // Algoritma Greedy untuk TSP
    for (int i = 1; i < numCities; ++i) {
        int nextCity = findNearestCity(currentCity, distanceMatrix, visited);
        if (nextCity != -1) {
            bestPath.push_back(nextCity);
            totalCost += distanceMatrix[currentCity][nextCity];
            currentCity = nextCity;
            visited[currentCity] = true;
        }
    }

    // Kembali ke kota awal untuk menyelesaikan siklus
    totalCost += distanceMatrix[currentCity][bestPath[0]];
    bestPath.push_back(bestPath[0]);


    // Output jalur terbaik
    cout << "Jalur terbaik: ";
    for (int city : bestPath) {
        cout << cityNames[city] << " ";
    }
    cout << endl;

    // Output biaya yang dibutuhkan
    cout << "Biaya yang dibutuhkan: " << totalCost << endl;

    // Output kelas kompleksitas waktu
    cout << "Kompleksitas waktu: O(n^2)" << endl;

    return 0;
}
